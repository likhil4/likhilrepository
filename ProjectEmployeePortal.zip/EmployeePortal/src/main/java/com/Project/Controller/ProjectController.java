package com.Project.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.Project.Dao.ProjectDao;
import com.Project.Bean.Employee;

@Controller
public class ProjectController {
	
	@Autowired
	ProjectDao dao;
	
	@RequestMapping("Welcome")
	public ModelAndView callWelcome()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Welcome");
		return mv;
	}
	@RequestMapping("About")
	public ModelAndView callAbout()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("About");
		return mv;
	}
	@RequestMapping("LandingPage")
	public ModelAndView callLandingPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LandingPage");
		return mv;
	}
	@RequestMapping("Login")
	public ModelAndView callLoginPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LoginPage");
		return mv;
	}
	@RequestMapping("Events")
	public ModelAndView callEvents()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Events");
		return mv;
	}
	@RequestMapping("ForgotPassword")
	public ModelAndView callForgotPassword()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ForgotPassword");
		return mv;
	}
	@RequestMapping("Home")
	public ModelAndView callHome()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Home");
		return mv;
	}
	@RequestMapping("Holidays")
	public ModelAndView callHolidays()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Holidays");
		return mv;
	}
	@RequestMapping("Leaves")
	public ModelAndView callLeaves()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Leaves");
		return mv;
	}
	@RequestMapping("MyLeaves")
	public ModelAndView callMyLeaves()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("MyLeaves");
		return mv;
	}
	@RequestMapping("ApplyForLeave")
	public ModelAndView callApplyForLeave()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ApplyForLeave");
		return mv;
	}
	@RequestMapping("ProfilePage")
	public ModelAndView callProfilePage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ProfilePage");
		return mv;
	}
	@RequestMapping("HelpPage")
	public ModelAndView callHelpPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("HelpPage");
		return mv;
	}
	@RequestMapping("CalenderPage")
	public ModelAndView callCalenderPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("CalenderPage");
		return mv;
	}
	@RequestMapping("WorkFromHome")
	public ModelAndView callWorkFromHome()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("WorkFromHome");
		return mv;
	}
	@RequestMapping("Carrers")
	public ModelAndView callCarrers()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Carrers");
		return mv;
	}
	@RequestMapping("News")
	public ModelAndView callNews()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("News");
		return mv;
	}
	@RequestMapping("InsertEmployee")
	public ModelAndView insertEmployeeObject(Employee employee)
	{
		ModelAndView mv = new ModelAndView();
		
		//Insert
		dao.save(employee);
		mv.setViewName("LandingPage");
		mv.addObject("msg","Employee Object Inserted");
		
		return mv;
	}
	
	@RequestMapping("LoginPage")
	public ModelAndView login(Employee employee) {
		ModelAndView mv = new ModelAndView();
		System.out.println("username="+employee.getUserName());
		Optional<Employee> obj = dao.findById(employee.getUserName());
		if(obj.isPresent()) {
			Employee tmp=obj.get();
		if(tmp.getPassWord().equals(employee.getPassWord())) {
		   mv.setViewName("Home");
		}
		else {
			mv.setViewName("LoginPage");
			mv.addObject("msg", "Invalid Username/Password pls check your Username/Password");
		}
		}
		else {
			mv.setViewName("LoginPage");
			mv.addObject("msg", "Invalid Username/Password pls check your Username/Password");
		}
		
		return mv;
	}
	

	

}
