package com.Project.Dao;
import org.springframework.data.repository.CrudRepository;
import com.Project.Bean.Employee;

public interface ProjectDao extends CrudRepository <Employee , String> {

}
