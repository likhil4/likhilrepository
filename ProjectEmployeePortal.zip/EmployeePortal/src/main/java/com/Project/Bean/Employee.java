package com.Project.Bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_employee")

public class Employee {
	
	@Column (name="id")
	private int id;
	
	@Column (name="name")
	private String Name;
	
	@Column (name="gender")
	private String Gender;
	
	@Column (name="age")
	private int Age;
	
	@Column (name="department")
	private String Department;
	
	
	@Column (name="address")
	private String Address;
	
	
	@Column (name="contact")
	private String Contact;
	
	@Id
	@Column (name="username")
	private String UserName;
	
	@Column (name ="Password")
	private String PassWord;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassWord() {
		return PassWord;
	}

	public void setPassWord(String passWord) {
		PassWord = passWord;
	}

	
		
	

}

