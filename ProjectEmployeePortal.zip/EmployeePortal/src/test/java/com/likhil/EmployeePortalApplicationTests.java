package com.likhil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
